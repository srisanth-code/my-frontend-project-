import { useLocation, useNavigate, Navigate } from 'react-router-dom';

export default function Result() {
  // useLocation gets the data (state) that was passed from the Home page
  const location = useLocation();
  const navigate = useNavigate();
  
  // Extract the result from the state
  const result = location.state?.result;

  // If there is no result (e.g. someone typed /result directly in the URL), send them back to home
  if (!result) {
    return <Navigate to="/" replace />;
  }

  // Get the specific details from the result object
  const aiProbability = result.aiProbability;
  const classification = result.classification;
  const textSnippet = result.textSnippet;
  const wordCount = result.wordCount;
  
  // Decide which color to show based on how likely it is AI
  let resultClass = "result-human"; // default to green (human)
  if (aiProbability >= 60) {
    resultClass = "result-ai"; // red (ai)
  } else if (aiProbability >= 40) {
    resultClass = "result-mixed"; // orange/yellow (mixed)
  }

  // A simple function to navigate back to the home page
  function handleGoBack() {
    navigate('/');
  }

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <button className="btn-secondary" onClick={handleGoBack} style={{ marginBottom: '20px' }}>
        Go Back to Scanner
      </button>

      <div className="simple-card" style={{ textAlign: 'center' }}>
        <h2>Analysis Complete</h2>
        
        {/* We use a simple HTML progress bar instead of a complex circle */}
        <div>
          <div className={`score-text ${resultClass}`}>
            {aiProbability}%
          </div>
          <progress value={aiProbability} max="100"></progress>
          
          <h3 className={resultClass}>
            {classification}
          </h3>
        </div>

        {/* Detailed breakdown section */}
        <div style={{ backgroundColor: '#121212', padding: '20px', borderRadius: '10px', marginTop: '30px', textAlign: 'left' }}>
          <h3>Detailed Breakdown</h3>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '15px' }}>
            <div>
              <p style={{ color: '#94a3b8' }}>Word Count</p>
              <p><strong>{wordCount} words</strong></p>
            </div>
          </div>

          <div style={{ marginTop: '20px' }}>
            <p style={{ color: '#94a3b8', marginBottom: '10px' }}>Text Analyzed</p>
            <p style={{ fontStyle: 'italic', color: '#dddddd' }}>
              "{textSnippet}"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
