import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Result from './pages/Result';


export default function App() {
  return (

    <Router>
      <div className="app-container">
        {/* The Navbar will show on every page */}
        <Navbar />
        
        <main className="main-content">
          {/* Routes decides which component to show based on the URL */}
          <Routes>
            {/* When the URL is exactly "/" (the home page), show the Home component */}
            <Route path="/" element={<Home />} />
            
            {/* When the URL is "/result", show the Result component */}
            <Route path="/result" element={<Result />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
