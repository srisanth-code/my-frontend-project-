import { NavLink } from 'react-router-dom';

// The Navbar component that shows at the top of the screen
export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="nav-brand">
        {/* We use basic text instead of complex icons */}
        <span>AIdentify</span>
      </div>
      
      <div className="nav-links">
        {/* NavLink is a special link from React Router that knows when it's active */}
        <NavLink to="/">
          Scanner
        </NavLink>
      </div>
    </nav>
  );
}
