// This function takes some text and decides if it was written by an AI or a human.
export function analyzeText(text) {
  // If the text is empty or just spaces, return nothing
  if (!text.trim()) {
    return null;
  }
  
  // Split the text into an array of words
  const words = text.trim().split(" ");
  const wordCount = words.length;
  
  // A simple list of words that AI often uses
  const aiKeywords = [
    'furthermore', 'moreover', 'delve', 'tapestry', 'testament', 
    'crucial', 'essential', 'undeniably', 'multifaceted'
  ];
  
  // Let's count how many AI keywords are in the text
  let keywordMatches = 0;
  for (let i = 0; i < words.length; i++) {
    const currentWord = words[i].toLowerCase();
    // Check if the current word is in our list of AI keywords
    if (aiKeywords.includes(currentWord)) {
      keywordMatches = keywordMatches + 1;
    }
  }
  
  // We start with a base probability that it's an AI
  let aiProbability = 30;
  
  // Each AI keyword adds to the probability
  aiProbability = aiProbability + (keywordMatches * 15);
  
  // Make sure the probability is not more than 99 and not less than 1
  if (aiProbability > 99) {
    aiProbability = 99;
  }
  if (aiProbability < 1) {
    aiProbability = 1;
  }
  
  // Decide the classification based on the score
  let classification = "Human Written";
  if (aiProbability >= 60) {
    classification = "AI Generated";
  }
  
  // Get a small piece of the text to show on the results page
  let textSnippet = text.substring(0, 100);
  if (text.length > 100) {
    textSnippet = textSnippet + "...";
  }
  
  // Return an object with all the information we found
  return {
      id: Math.random().toString(), // Create a random ID
      textSnippet: textSnippet,
      wordCount: wordCount,
      aiProbability: aiProbability,
      classification: classification,
      timestamp: new Date().toISOString()
  };
}
